MJ Agro TAVAAZO — Google Tag Manager Runtime Patch
Container: GTM-5TDFPGWF

What this patch changes
- Inserts the official GTM <head> script and <body> noscript snippet into all 41 prerendered Next.js HTML files.
- It does not install the GA4 measurement tag by itself. Configure GA4 inside Google Tag Manager using G-5P3MYVNMLX.

Deployment in Hostinger File Manager
1. Back up the current nodejs folder.
2. Open the nodejs folder.
3. Upload MJ_AGRO_GTM_RUNTIME_PATCH.zip.
4. Extract it inside nodejs (not inside public_html).
5. Allow overwrite/replace for matching files under .next/server/app.
6. Restart/redeploy the Node.js application from Hostinger.
7. Open https://trade.mjagrogroup.com in an incognito window.
8. In Google Tag Manager, click Preview and connect to the site.

Rollback
- Extract MJ_AGRO_GTM_RUNTIME_ROLLBACK.zip inside nodejs and overwrite matching files, then restart the application.

Important limitation
This archive contains compiled runtime output, not the original Next.js source (app/layout.tsx). A future rebuild/deployment can overwrite this patch. The durable solution is to add GTM to the original root layout and rebuild.
